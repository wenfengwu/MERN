import React, { useState } from 'react'

const PokemonAPI = () => {
    const [pokemons, setPokemons] = useState([]);

    const fetchHandler = () => {
        fetch("https://pokeapi.co/api/v2/pokemon")
        .then(response => {
            return response.json();
        }).then(response => {
            setPokemons(response.results);
        })
    }

    return (
        <div>
            <button onClick = {fetchHandler}>Fetch Pokemon</button>
            {pokemons.map((pokemon, idx) => {
                return <p key = {idx}>Pokemon: {idx} - {pokemon.name}</p> 
            })}
        </div>
    )
}

export default PokemonAPI;