import React, { useState } from 'react';
import axios from 'axios';

const PokemonAPI = () => {
    const [pokemons, setPokemons] = useState([]);

    const fetchHandler = () => {
        axios("https://pokeapi.co/api/v2/pokemon")
        .then(response => {
            setPokemons(response.data.results);
        }).catch(error => {
            console.log("404 NOT FOUND");
        })
    }

    return (
        <div>
            <button onClick = {fetchHandler}>Fetch Pokemon</button>
            {pokemons.map((pokemon, idx) => {
                return <p key = {idx}>Pokemon: {idx} - {pokemon.name}</p> 
            })}
        </div>
    )
}

export default PokemonAPI;