import "./App.css";
 import PokemonAPI from "./components/PokemonAPI";

function App() {

  return(
    <PokemonAPI />
  );
}

export default App;
