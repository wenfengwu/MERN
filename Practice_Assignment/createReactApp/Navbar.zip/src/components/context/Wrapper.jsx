import { createContext } from "react";

const Wrapper = createContext();

export default Wrapper;