import "./App.css";
// import About from './components/About';
// import Home from './components/Home';
import React from "react";
import {BrowserRouter, Switch, Route} from 'react-router-dom';
import { useParams } from "react-router";

// function App() {

//   return(
//     <BrowserRouter>
//         <h1>
//           Routing Example
//         </h1>
//         <p>
//           <Link to = "/">Home</Link>
//           |
//           <Link to = "/about">About</Link>
//         </p>
//         <Switch>
//           <Route path = "/about"><About /></Route>
//           <Route exact path = "/"><Home /></Route>
//         </Switch>
//     </BrowserRouter>
//   );
// }
const Location = (props) => {
  const {city} = useParams();
  let renderText = "";
  if(city === "home"){
    renderText = "Welcome";
  }
  else if(isNaN(city)){
    renderText = `The word is: ${city}`;
  }
  else{
    renderText = `The number is: ${city}`;
  }
  return (
    <h1 style = {{textAlign: "center"}}>{renderText}</h1>
  );
}

const Colorful = (props) => {

  const {word, wordColor, bgColor} = useParams();
  

  return (
    
    <h1 style = {{color: wordColor, backgroundColor: bgColor, textAlign: "center"}}>The word is: {word}</h1>
  )
}
    
function App() {

  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/location/:city">
          <Location />
        </Route>
        <Route exact path="/location/:word/:wordColor/:bgColor">
          <Colorful />
        </Route>
      </Switch>
    </BrowserRouter>
  );
}
    
export default App;