import React from 'react'

const About = () => {
    return (
        <div style = {{backgroundColor: "purple"}}>
            About Component is here !
        </div>
    )
}

export default About;