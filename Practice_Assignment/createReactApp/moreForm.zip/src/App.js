import "./App.css";
import React from "react";
import HookForm from "./components/HookForm";

function App() {
  return <HookForm></HookForm>;
}

export default App;
