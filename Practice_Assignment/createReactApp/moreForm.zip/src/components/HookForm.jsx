import React, { useState } from "react";

const divStyle = {
  padding: "12px 15px",
};

const HookForm = (props) => {
  const [data, setData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirm: "",
  });
  // const [error1, setError1] = useState("");
  // const [error2, setError2] = useState("");
  // const [error3, setError3] = useState("");
  // const [error4, setError4] = useState("");
  // const [error5, setError5] = useState("");

  const captureInputs = (e) => {
    setData({
      ...data,
      [e.target.name]: e.target.value,
    });
    // data.firstName.length < 2
    //   ? setError1("Field must be at least 2 character")
    //   : setError1("");
    // data.lastName.length < 2
    //   ? setError2("Field must be at least 2 character")
    //   : setError2("");
    // data.email.length < 5
    //   ? setError3("Field must be at least 5 character")
    //   : setError3("");
    // data.password.length < 8
    //   ? setError4("Field must be at least 8 character")
    //   : setError4("");
    // data.password !== data.confirm
    //   ? setError5("Passwords do not match")
    //   : setError5("");
  };

  return (
    <div>
      <div style={divStyle}>
        <label>First Name: </label>
        <input
          type="text" onChange={captureInputs} name="firstName" value={data.firstName} />
          {
            data.firstName.length < 2 && data.firstName.length > 0 ? <p style = {{color: "red"}}>Field must be at least 2 character</p> : ""
          }
      </div>
      <div style={divStyle}>
        <label>Last Name: </label>
        <input
          type="text"
          onChange={captureInputs}
          name="lastName"
          value={data.lastName}
        />
          {
            data.lastName.length < 2 && data.lastName.length > 0 ? <p style = {{color: "red"}}>Field must be at least 2 character</p> : ""
          }
      </div>
      <div style={divStyle}>
        <label>Email: </label>
        <input
          type="email"
          onChange={captureInputs}
          name="email"
          value={data.email}
        />
          {
            data.email.length < 5 && data.email.length > 0 ? <p style = {{color: "red"}}>Field must be at least 5 character</p> : ""
          }
      </div>
      <div style={divStyle}>
        <label>Password: </label>
        <input
          type="password"
          onChange={captureInputs}
          name="password"
          value={data.password}
        />
          {
            data.password.length < 8 && data.password.length > 0 ? <p style = {{color: "red"}}>Field must be at least 8 character</p> : ""
          }
      </div>
      <div style={divStyle}>
        <label>Confirm Password: </label>
        <input
          type="password"
          onChange={captureInputs}
          name="confirm"
          value={data.confirm}
        />
          {
             data.confirm !== data.password && data.confirm.length > 0 ? <p style = {{color: "red"}}> Passwords do not match</p> : ""
          }
      </div>

      <h3>Your Form Data</h3>
      <p>First Name: {data.firstName}</p>
      <p>Last Name: {data.lastName}</p>
      <p>Email: {data.email}</p>
      <p>Password: {data.password}</p>
      <p>Confirmm Password: {data.confirm}</p>
    </div>
  );
};

export default HookForm;
