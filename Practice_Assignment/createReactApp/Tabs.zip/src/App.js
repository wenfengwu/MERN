import "./App.css";
import React, {useState} from "react";
import BoxGenerate from "./components/Tabs";
import Tabs from "./components/Tabs";

function App() {

  return(
    <>
        <Tabs />
        {/* {JSON.stringify(currentBoxs)} */}
    </>
  );
}

export default App;
